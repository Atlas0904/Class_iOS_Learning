//
//  ArticlesViewController.swift
//  NewsReader
//
//  Created by Denny Tsai on 3/20/16.
//  Copyright © 2016 hpd.io. All rights reserved.
//

import UIKit

class ArticlesViewController: BaseArticlesViewController {

}
