//
//  ViewController.swift
//  taxiCost
//
//  Created by atlas on 2016/3/14.
//  Copyright © 2016年 atlas. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var currentPlace: String = "taipei"
    var dist: Int = 0;
    var delay: Int = 0;
    var night: Bool = false;
    

    @IBOutlet weak var inputTextDist: UITextField!
    
    @IBOutlet weak var inputTextDelay: UITextField!
    
    
    @IBOutlet weak var labelNightMode: UILabel!
    @IBOutlet weak var labelCount: UILabel!
    @IBOutlet weak var switchNightMode: UISwitch!
    
    @IBAction func actionCountCostInTpe(sender: AnyObject) {
        dist = Int(Double((inputTextDist.text)!)! * 1000)
        delay = Int(Double((inputTextDelay.text)!)! * 60)
        night = switchNightMode.on;
        countTaxiFee("taipei", distMeter: dist, delaySec: delay, nightMode: night)
    }

    @IBAction func actionCountCostInTaiChung(sender: AnyObject) {
        dist = Int(Double((inputTextDist.text)!)! * 1000)
        delay = Int(Double((inputTextDelay.text)!)! * 60)
        night = switchNightMode.on;
        countTaxiFee("taichung", distMeter: dist, delaySec: delay, nightMode: night)
    
    }

    @IBAction func actionCountCostInKaoSiung(sender: AnyObject) {
        dist = Int(Double((inputTextDist.text)!)! * 1000)
        delay = Int(Double((inputTextDelay.text)!)! * 60)
        night = switchNightMode.on;
        countTaxiFee("kaosiung", distMeter: dist, delaySec: delay, nightMode: night)
    }
    
    func countTaxiFee (place: String, distMeter: Int, delaySec: Int, nightMode: Bool) {
        var price: Int = 0
        
        let startDistMeter: Int
        let startPrice: Int
        
        let perCostWithDist: Int
        let perDistKmPrice: Int
        let perDelayCost: Int
        let perCostWithDelaySec: Int
        
        let additionBilling: Int
        let additionBillingRate: Double
        
        if place=="taipei" {
            currentPlace = "taipei"
            
            startDistMeter = 1250
            startPrice = 70
            perCostWithDist = 200
            perDistKmPrice = 5
            perDelayCost = 5
            perCostWithDelaySec = 1 * 60 + 20
            
            additionBilling = 20
            additionBillingRate = 0
            
        } else if place == "taichung" {
            currentPlace = "taichung"
            
            startDistMeter = 1500
            startPrice = 85
            perCostWithDist = 250
            perDistKmPrice = 5
            perDelayCost = 5
            perCostWithDelaySec = 3 * 60
            additionBilling = 20
            additionBillingRate = 0.2
            
        } else if place == "kaosiung" {
            currentPlace = "kaosiung"
            
            startDistMeter = 1500
            startPrice = 85
            perCostWithDist = 250
            perDistKmPrice = 5
            perDelayCost = 5
            perCostWithDelaySec = 3 * 60
            additionBilling = 20
            additionBillingRate = 0.2
        } else {
            startDistMeter = 1250
            startPrice = 70
            perCostWithDist = 200
            perDistKmPrice = 5
            perDelayCost = 5
            perCostWithDelaySec = 1 * 60 + 20
            additionBilling = 20
            additionBillingRate = 0
        }
        
        var count: Double = Double(distMeter - startDistMeter) / Double(perCostWithDist)
        let countSec: Int = Int(delaySec/perCostWithDelaySec)
        
        count = (count >= 0) ? floor(count): 0
        price += startPrice + Int(count) * perDistKmPrice
        price += countSec * perDelayCost
        price = nightMode ? Int(Double(price + additionBilling) * (1+additionBillingRate)) : price
        
        labelCount.text = "\(price)"
    }
    
    func stateChanged(nightMode: UISwitch) {
        
        if nightMode.on {
            labelNightMode.text = "ON"
        } else {
            labelNightMode.text = "OFF"
        }
        
        countTaxiFee(currentPlace, distMeter: dist, delaySec: delay, nightMode: nightMode.on)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        switchNightMode.addTarget(self, action: Selector("stateChanged:"), forControlEvents: UIControlEvents.ValueChanged)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

